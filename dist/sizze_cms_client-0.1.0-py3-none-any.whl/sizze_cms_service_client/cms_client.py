from api import fields, storage, tables, values


field_client = fields.FieldsClient
storage_client = storage.StorageClient
table_client = tables.TableClient
value_client = values.ValuesClient
